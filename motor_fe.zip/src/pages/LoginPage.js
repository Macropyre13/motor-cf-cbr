import { Link } from 'react-router-dom';
import Motor from '../assets/motor_jumbotron.png';

export default function LoginPage(){
    return (
      
        <div className="container d-flex justify-content-center align-items-center min-vh-100">
  <div className="row border rounded-5 p-3 bg-dark shadow box-area justify-content-center mx-2">
    {/* <div class="col-md-6 rounded-4 d-flex justify-content-center align-items-center flex-column left-box" style="background: #103cbe;">
             </div>  */}
    <div className="col-md-6 right-box">
      <div className="row align-items-center">
        <div className="header-text mb-4" style={{ color: "white" }}>
          <h2>Selamat Datang</h2>
          <p>Login Sebagai Admin.</p>
        </div>
        <div className="input-group mb-3">
          <input
            type="text"
            className="form-control form-control-lg bg-light fs-6"
            placeholder="Username"
          />
        </div>
        <div className="input-group mb-1">
          <input
            type="password"
            className="form-control form-control-lg bg-light fs-6"
            placeholder="Password"
          />
        </div>
        <div className="input-group mb-3">
          <Link to={'/admin'} className="btn btn-lg btn-primary w-100 fs-6 mt-2">Login</Link>
        </div>
      </div>
    </div>
  </div>
</div>

    )
}