import NavbarComp from '../components/NavbarComp';
import HeaderComp  from '../components/HeaderComp';
import FooterComp from '../components/FooterComp';

import MotorImg1 from '../assets/1.png';
import MotorImg2 from '../assets/2.png';
import MotorImg3 from '../assets/3.png'
import { Link } from 'react-router-dom';

const HomePage = () => {
    return (
        <div className="d-flex flex-column h-100">
            <main className="flex-shrink-0">
                <NavbarComp/>
                <HeaderComp/>

                <section className="py-5" id="features">
                    <div className="container px-5 my-5">
                        <div className="row gx-5">
                            <div className="col-lg-8">
                                <div className="row gx-5 row-cols-1 row-cols-md-2">
                                    <div className="col mb-5 h-100">
                                        <Link to={'/data/kerusakan'}>
                                            <button type="button" className="btn btn-success">
                                                <i className="bi bi-archive-fill" />
                                            </button>
                                        </Link>
                                        <h2 className="h5">Data Kerusakan</h2>
                                        <p className="mb-0">
                                            Menampilkan seluruh data kerusakan motor
                                        </p>
                                    </div>
                                    <div className="col mb-5 h-100">
                                        <Link to={'/diagnosa'}>
                                            <button type="button" className="btn btn-success">
                                                <i className="bi bi-archive-fill" />
                                            </button>
                                        </Link>
                                        <h2 className="h5">Diagnosa</h2>
                                        <p className="mb-0">
                                            Melakukan diagnosa terhadap motor
                                        </p>
                                    </div>
                                    {/* <div className="col mb-5 h-100">
                                        <Link to={'/data/gejala'}>
                                            <button type="button" className="btn btn-success">
                                                <i className="bi bi-archive-fill" />
                                            </button>
                                        </Link>
                                        <h2 className="h5">Data Gejala</h2>
                                        <p className="mb-0">
                                            Paragraph of text beneath the heading to explain the heading. Here
                                            is just a bit more text.
                                        </p>
                                    </div> */}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                {/* <div className="py-5 bg-light">
                    <div className="container px-5 my-5">
                        <div className="row gx-5 justify-content-center">
                            <div className="row justify-content-center mb-3">
                                <div className="text-center">
                                    <h2 className="fw-bolder">Metode Sistem Pakar</h2>
                                </div>
                            </div>
                            <div className="text-center">
                                <div className="fs-4 mb-4">"Metode Sistem Pakar Certainty factor"</div>
                                <div className="fs-4 mb-4 fst-italic">
                                    "Metode Certainty Factor adalah metode yang mendefinisikan keyakinan
                                    terhadap suatu fakta atau aturan berdasarkan tingkat keyakinan seorang
                                    pakar"
                                </div>
                            </div>
                            <div className="text-center">
                                <div className="fs-4 mb-4 pt-2">
                                    "Metode Sistem Pakar Case Based Reasoning"
                                </div>
                                <div className="fs-4 mb-4 fst-italic">
                                    "Metode Case Based Reasoning (CBR) adalah salah satu metode untuk
                                    membangun sebuah sistem yang bekerja dengan cara mendiagnosa kasus
                                    baru berdasarkan kasus lama yang pernah terjadi dan memberikan solusi
                                    pada kasus baru berdasarkan pada kasus lama yang memiliki nilai
                                    kemiripan tertinggi."
                                </div>
                            </div>
                        </div>
                    </div>
                </div> */}

                {/* <section className="py-5">
                    <div className="container px-5 my-5">
                        <div className="row gx-5 justify-content-center">
                            <div className="col-lg-8 col-xl-6">
                                <div className="text-center">
                                    <h2 className="fw-bolder">Alur Kerja Sistem Pakar Motor Admin</h2>
                                    <p className="lead fw-normal text-muted mb-5">
                                        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eaque
                                        fugit ratione dicta mollitia. Officiis ad.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div className="row gx-5">
                            <div className="col-lg-4 mb-5">
                                <div className="card h-100 shadow border-0">
                                    <img
                                        className="card-img-top"
                                        src={MotorImg1}
                                        alt="..."
                                    />
                                    <div className="card-body p-4">
                                        <div className="badge bg-primary bg-gradient rounded-pill mb-2">
                                            Masuk Website
                                        </div>
                                        <a
                                            className="text-decoration-none link-dark stretched-link"
                                            href="#!"
                                        >
                                            <h5 className="card-title mb-3">Blog post title</h5>
                                        </a>
                                    </div>
                                    <div className="card-footer p-4 pt-0 bg-transparent border-top-0">
                                        <div className="d-flex align-items-end justify-content-between"></div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-4 mb-5">
                                <div className="card h-100 shadow border-0">
                                    <img
                                        className="card-img-top"
                                        src={MotorImg2}
                                        alt="..."
                                    />
                                    <div className="card-body p-4">
                                        <div className="badge bg-primary bg-gradient rounded-pill mb-2">
                                            Tes Gejala Pasien
                                        </div>
                                        <a
                                            className="text-decoration-none link-dark stretched-link"
                                            href="#!"
                                        >
                                            <h5 className="card-title mb-3">Another blog post title</h5>
                                        </a>
                                    </div>
                                    <div className="card-footer p-4 pt-0 bg-transparent border-top-0">
                                        <div className="d-flex align-items-end justify-content-between"></div>
                                    </div>
                                </div>
                            </div>
                            <div className="col-lg-4 mb-5">
                                <div className="card h-100 shadow border-0">
                                    <img
                                        className="card-img-top"
                                        src={MotorImg3}
                                        alt="..."
                                    />
                                    <div className="card-body p-4">
                                        <div className="badge bg-primary bg-gradient rounded-pill mb-2">
                                            Hasil dan Solusi
                                        </div>
                                        <a
                                            className="text-decoration-none link-dark stretched-link"
                                            href="#!"
                                        >
                                            <h5 className="card-title mb-3">
                                                The last blog post title is a little bit longer than the others
                                            </h5>
                                        </a>
                                    </div>
                                    <div className="card-footer p-4 pt-0 bg-transparent border-top-0">
                                        <div className="d-flex align-items-end justify-content-between"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section> */}

            </main>
            <FooterComp/>
        </div>
    )
}

export default HomePage;