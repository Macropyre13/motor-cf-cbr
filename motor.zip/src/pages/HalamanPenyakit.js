import {useState, useEffect} from 'react';
import {Link, useParams} from 'react-router-dom'
import axios from 'axios';
import NavbarComp from '../components/NavbarComp';
import AboutSection from '../components/AboutSection';
import FooterComp from '../components/FooterComp';

export default function HalamanPenyakit(){
    const {penyakitId} = useParams();
    const [penyakit,setPenyakit] = useState();

    const getPenyakit = async () => {
        const res = await axios.get(`http://localhost:8000/api/kerusakan/${penyakitId}`);
        console.log(res.data)
        setPenyakit(res.data)
    }

    useEffect(() => {
        getPenyakit();
    },[])
    return (
        <>
            <NavbarComp/>
            <header className="py-5 bg-dark">
                <div className="container px-5">
                <div className="row justify-content-center">
                    <div className="col-lg-8 col-xxl-6">
                    <div className="text-center my-5">
                        <h1 className="fw-bolder mb-3" style={{ color: "white" }}>
                        DATA GEJALA
                        </h1>
                    </div>
                    </div>
                </div>
                </div>
            </header>

            <div className="container">
                <div className="card" >
                    <img src={`http://localhost:8000${penyakit && penyakit.gambar}`}className="card-img-top" alt="..." />
                    <div className="card-body">
                        <h3>{penyakit && penyakit.nama}</h3>
                        <p className="card-text">{penyakit && penyakit.deskripsi}</p>
                        <strong>Solusi:</strong>
                        <p className="card-text">{penyakit && penyakit.solusi}</p>
                    </div>
                </div>
            </div>

            <FooterComp />

        </>
    )
}